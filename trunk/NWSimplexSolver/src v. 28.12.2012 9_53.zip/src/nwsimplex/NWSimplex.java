/*
 #  * To change this template, choose Tools | Templates
 #  * and open the template in the editor.
 */
package nwsimplex;

import java.util.LinkedList;
import nwsimplex.graph.Edge;

/**
 *
 * @author mfj
 */
public class NWSimplex
{
    private int cost;
    
    private LinkedList<Edge> L;
    
    private LinkedList<Edge> U;
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        // TODO code application logic here
    }
    
}
