package nwsimplex.graph.util;

import nwsimplex.graph.Edge;
import nwsimplex.graph.Vertex;

/**
 * A class that represents an adjacency matrix used by a graph. This
 * implementation uses a hashset approach to ensure efficient memory usage.
 * Note: this class does not support a fastfial approach. if any of the given
 * nodes or edges are {@code null} the matrix might produce an error later.
 *
 * @author mfj
 */
public class AdjacencyMatrix
{
    /**
     * The table, resized as necessary. Length MUST Always be a power of two.
     */
    private Entry[] table;
    /**
     * The number of entries of this hash table.
     */
    private int size = 0;

    /**
     * The largest possible index within the hashtable
     */
    private final int lastIndex;
    /**
     * Constructs an empty <tt>AdjacencyMatrix</tt> which capacity is optimized
     * for the specified number of vertives and edges.
     *
     * @param numberOfVertices the total number of vertices
     * @param numberOfEdges then total number of edges
     * @throws IllegalArgumentException if the number of edges or vertices is
     * nonpositive
     */
    public AdjacencyMatrix(int numberOfVertices, int numberOfEdges)
    {
        if (numberOfVertices <= 0)
            throw new IllegalArgumentException("Illegal number of vertices: " + numberOfVertices);
        if (numberOfEdges <= 0)
            throw new IllegalArgumentException("Illegal number of edges: " + numberOfEdges);

        int capacity = Math.max(numberOfVertices << 1, numberOfEdges) + 1;
        this.table = new Entry[capacity];
        this.lastIndex = capacity - 1;
    }


    /**
     * Returns the number of mappings.
     *
     * @return the number of mappings
     */
    public int size()
    {
        return size;
    }

    /**
     * Gets the index of an edge connecting two vertices within the hashtable.
     */
    private int indexFor(Vertex u, Vertex v)
    {
        // hashCode() returns the id of the node, therefor if the range of all
        // ids is small enough v.hashCode() << 16 ^ u.hashCode() is an injective
        // function ranging from 0 to n^2
        return Math.abs(v.hashCode() << 16 ^ u.hashCode()) % lastIndex;
    }

    /**
     * Returns the edge assoziated with the specified vertices, or {@code null}
     * if no such edge exists. Note: this method does not check if any of the
     * given nodes is zero.
     *
     * @param u the source vertiex
     * @param v the target vertex
     */
    public Edge get(Vertex u, Vertex v)
    {
        Entry e = table[indexFor(u, v)];
        if(e == null || (e = e.get(u,v)) == null)
            return null;
        return e.edge;
    }

    /**
     * Adds a new edge entry tho the matrix.
     * @param edge the edge to be assoziated with its adjacent vertices
     * @return {@code null} if no edge connecting both vertices exists, the
     * replaced edge otherwise
     */
    public Edge put(Edge edge)
    {
        size++;
        int i = indexFor(edge.from, edge.to);
        Entry e = table[i];
        if(e == null)
        {
            table[i] = new Entry(edge);
            return null;
        }
        return e.add(edge);
    }
    
    /**
     * A recursive search tree that uses the natural order of an edge defined by
     * the ids of the adjacent nodes.
     */
    private class Entry
    {

        /**
         * the edge stored in this entry.
         */
        Edge edge;
        /**
         * the next smaller entry
         */
        Entry smaller;
        /**
         * the next bigger entry
         */
        Entry bigger;

        /**
         * Instantiates a new entry
         *
         * @param e the edge represented by this entry
         */
        public Entry(Edge e)
        {
            this.edge = e;
        }

        /**
         * Adds a new entry by either adding a new entry to this search tree or
         * by replacing the given edge if both edges are equal as defined by the 
         * compareTo method.
         * @param e the edge the new edge
         * @return {@code null} if the edge is not contained in this search tree,
         * or the replaced edge otherwise.
         */
        public Edge add(Edge e)
        {
            int cmp = e.compareTo(edge);
            if (cmp < 0)
            {
                if (smaller == null)
                {
                    this.smaller = new Entry(e);
                    return null;
                }
                return smaller.add(e);
            }
            else if (cmp > 0)
            {
                if (bigger == null)
                {
                    this.bigger = new Entry(e);
                    return null;
                }
                return bigger.add(e);
            }
            
            return this.edge = e;
        }

        /**
         * Gets the entry which corresponds with the specified vertices.
         * @param u the outgoing vertex
         * @param v the ingoing vertex
         * @return the edge e with {@code e.from.ID == u.ID && e.to.ID == v.ID} or
         * null if no such edge exists.
         */
        Entry get(Vertex u, Vertex v)
        {
            int cmp = edge.compareTo(u,v);
            if(cmp < 0)
                return smaller == null ? null : smaller.get(u,v);
            if(cmp > 0)
                return bigger == null ? null : bigger.get(u,v);
            return this;
        }        
    }
}
