package nwsimplex.graph;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * A Spanning Tree Structure, that applies the cycle canceling rule and manages
 * the reduced cost.
 *
 * @author mfj
 */
public class SpanningTree
{

    /**
     * the graph of this spanning tree
     */
    public Graph graph;
    /**
     * the root node of this spanning tree
     */
    public final Vertex ROOT;
    // the root of the cycle
    private Vertex cycleRoot;
    // while incrementing from the left or right side, the leaving arc can
    // either be located left or right
    private boolean leavingIsLeft;
    private Edge lEdge;
    private int minDelta;
    private LinkedList<Edge> inOrientation = new LinkedList<Edge>();
    private LinkedList<Edge> preOrientation = new LinkedList<Edge>();

    public SpanningTree(Graph graph)
    {
//        super(graph.numberOfVertices + 1);
//        this.vertices = (Vertex[]) Arrays.copyOf(graph.vertices, numberOfVertices);
//        this.ROOT = vertices[lastNodeId = numberOfVertices - 1] = new Vertex(numberOfVertices, 0);

        this.ROOT = null;

        // TODO initialize
        // rememeber to add artificial edges
    }

    public void addEdge(Edge edge)
    {
        // reset state of leaving arch slgorithm
        this.minDelta = Integer.MAX_VALUE;
        inOrientation.clear();
        preOrientation.clear();

        if (edge.hasUpperBound())
        {
            inOrientation.add(edge);
            identifyCycle(edge.from, edge.to, true);

            if (edge != lEdge)
                if (leavingIsLeft)
                    updatePredessesors(edge.from, edge.to);
                else
                    updatePredessesors(edge.to, edge.from);
        }
        else if (edge.hasLowerBound())
        {
            preOrientation.add(edge);
            identifyCycle(edge.to, edge.from, false);

            if (edge != lEdge)
                if (leavingIsLeft)
                    updatePredessesors(edge.to, edge.from);
                else
                    updatePredessesors(edge.from, edge.to);
        }
        else
            throw new IllegalArgumentException();

        augment();
        updateNodeParameters();
    }

    /**
     * Identifies a cycle within the spanningtree T, when adding a new edge
     * given by first, second), asuming of course that (first, second) is not in
     * E(T) also computes the min delta and sorts all edges into inOrder and
     * preOrder
     *
     * @param left vertex which is located left
     * @param right vertex which is located right
     * @param getFirstMin determines wheter to get the first possible min within
     * the left subcycle = {left, left.predessesor, ... , cycleRoot}
     *
     */
    private void identifyCycle(Vertex left, Vertex right, boolean getFirstMin)
    {
        while (left != right) // go up until cycle root is reached
            // second is closer to top -> move first up
            if (left.depth >= right.depth)
            {
                identifyEdge(left, left.predesessor, !getFirstMin, true);
                left = left.predesessor;
            }
            // first is closer to top -> move second up
            else if (left.depth <= right.depth)
            {
                identifyEdge(right.predesessor, right, getFirstMin, false);
                right = right.predesessor;
            }

        this.cycleRoot = left;
    }

    private void identifyEdge(Vertex u, Vertex v, boolean updateMinDeltaEq, boolean formLeft)
    {
        int currDelta;
        // e is forward edge
        Edge e = graph.getEdge(u, v);
        if (e != null)
        {
            currDelta = e.upperCapacity - e.flow;
            inOrientation.add(e);
        }
        // e is backward edge
        else
        {
            e = graph.getEdge(v, u);
            currDelta = e.flow;
            preOrientation.add(e);
        }

        // check if leaving arc needs to be updatet
        if (currDelta < minDelta || (updateMinDeltaEq && currDelta == minDelta))
        {
            this.minDelta = currDelta;
            this.lEdge = e;
            this.leavingIsLeft = formLeft;
        }
    }

    // augments all edges
    private void augment()
    {
        for (Edge edge : inOrientation)
            edge.flow += minDelta;
        for (Edge edge : preOrientation)
            edge.flow -= minDelta;
    }

    private void updatePredessesors(Vertex u, Vertex v)
    {
        Vertex maxLeaving, minLeaving;
        if (lEdge.from.depth < lEdge.to.depth)
        {
            maxLeaving = lEdge.to;
            minLeaving = lEdge.from;
        }
        else
        {
            maxLeaving = lEdge.from;
            minLeaving = lEdge.to;
        }
        minLeaving.removeTreeSuccsessor(maxLeaving);

        Vertex maxEntering, minEntering;
        if (u.depth < v.depth)
        {
            maxEntering = v;
            minEntering = u;
        }
        else
        {
            maxEntering = u;
            minEntering = v;
        }

        minLeaving.removeTreeSuccsessor(maxLeaving);
        minEntering.addTreeSuccsessor(maxEntering);

        // increment to minV
        Vertex current = u, previous = v;
        while (current != maxLeaving)
        {
            Vertex predesessor = current.predesessor;
            current.predesessor = previous;
            previous = current;
            current = predesessor;
        }
    }

    private Iterator<Vertex> dfsIterator(Vertex start)
    {
        return null;
    }

    private void updateNodeParameters()
    {
        // TODO updatde node potentials
    }

}
