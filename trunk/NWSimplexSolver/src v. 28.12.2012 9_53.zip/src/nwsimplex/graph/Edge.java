package nwsimplex.graph;

/**
 *
 * @author mfj
 */
public class Edge implements Comparable<Edge>
{

    /**
     * the current flow of this edge
     */
    public int flow;
    /**
     * the cost of this edge
     */
    public final int cost;
    /**
     * the lower capacity of this edge
     */
    public final int lowerCapacity;
    /**
     * the upper capacity of this edge
     */
    public final int upperCapacity;
    /**
     * the vertiex from which this edge goes out
     */
    public final Vertex from;
    /**
     * the vertex from which this edge goes in
     */
    public final Vertex to;

    /**
     *
     * @param flow
     * @param cost
     * @param lowerCapacity
     * @param upperCapacity
     * @param from
     * @param to
     */
    public Edge(int flow, int cost, int lowerCapacity, int upperCapacity, Vertex from, Vertex to)
    {
        this.flow = flow;
        this.cost = cost;
        this.lowerCapacity = lowerCapacity;
        this.upperCapacity = upperCapacity;
        this.from = from;
        this.to = to;
    }

    /**
     * Indicates that the edge flow reaches the lower bound
     *
     * @return {@code flow == lowerCapacity}
     */
    public boolean hasLowerBound()
    {
        return flow == lowerCapacity;
    }

    /**
     * Indicates that the edge flow reaches the upper bound
     *
     * @return {@code flow == capacity}
     */
    public boolean hasUpperBound()
    {
        return flow == upperCapacity;
    }

    @Override
    public boolean equals(Object o)
    {
        return o instanceof Edge && equals((Edge) o);
    }

    @Override
    public int compareTo(Edge e)
    {
        return compareTo(e.from, e.to);
    }
    
    public int compareTo(Vertex u, Vertex v)
    {      
        if (from.ID < u.ID)
            return -1;
        if (from.ID > u.ID)
            return 1;
        if (to.ID < v.ID)
            return -1;
        if (to.ID > v.ID)
            return 1;
        return 0;
    }

}
