package nwsimplex.util;

/**
 *
 * @author Kseniya
 */
public abstract class ParserConstants {

    public static final String DIGIT_PATTERN = "-?\\d+";
}
