package nwsimplex.IO.read;

/**
 * An interface that defines a raw data while parsing. No behaivour specifies,
 * just for convenience reasons.
 * 
 * @author Kseniya
 */
public interface RawLineData {
    
}
