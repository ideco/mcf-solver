package nwsimplex.util;

import java.util.*;
import nwsimplex.graph.Edge;

/**
 * A LinkedList which is connected in a cyclic way and has most of the
 * propperties of a <tt>LinkedList<tt>: supports O(1) add and removal
 * operations. contains needs O(n).
 *
 * The main differnence however lies in the behayviour of the iterator, which is
 * a bit more faster and does not support a fast fail approach. instead the
 * iterator stays in tact, as long as there are elements in this list.
 * furthermore the current porition can be marked, since there ist no end of a
 * cyclic list.
 *
 * @author mfj
 */
public class CycleList<T> extends AbstractSequentialList<T>
{

    private int size = 0;
    private Entry head, tail;

    @Override
    public ListIterator<T> listIterator(int i)
    {
        return new CycleListIterator(i);
    }

    @Override
    public int size()
    {
        return size;
    }

    public CycleListIterator cycleListIterator()
    {
        return new CycleListIterator();
    }

    public CycleListIterator cycleListIterator(int i)
    {
        return new CycleListIterator(i);
    }

    private void addEntry(T key, Entry entry)
    {
        if (size == 0)
        {
            head = tail = new Entry(key, null, null);
            head.next = head;
            head.previous = head;
        }
        else
        {
            Entry previous = entry.previous;
            previous.next = entry.previous = new Entry(key, entry, previous);
            
            if (entry == tail)
                tail = tail.previous;
        }
        size++;
    }

    private void removeEntry(Entry entry)
    {
        if (size == 1)
            head = tail = null;
        else
        {
            Entry next = entry.next, previous = entry.previous;
            next.previous = previous;
            previous.next = next;
            entry.next = entry.previous = null;
            
            if (entry == tail)
                tail = next;

        }
        size--;
    }

    /**
     * Represents an entry for this list.
     */
    public class Entry
    {

        public T key;
        public Entry next;
        public Entry previous;

        public Entry(T key, Entry next, Entry previous)
        {
            this.key = key;
            this.next = next;
            this.previous = previous;
        }

    }

    /**
     * A faster ListIterator which does not support the failfast philosophy.
     * This iterator provides a ready method to check wheter the state of the
     * iterator is valid. Removing an element automatically advances the
     * position of the current element. Hence no check for a modcount is needed.
     */
    public class CycleListIterator implements ListIterator<T>
    {

        private int index;
        private Entry curr, mark;

        public CycleListIterator()
        {
            index = 0;
            mark = curr = head;
        }

        public CycleListIterator(int i)
        {
            if (head == null)
                throw new NoSuchElementException();

            index = i;
            curr = head;
            if (i >= 0)
                while (--i >= 0)
                    curr = curr.next;
            else
                while (--i >= 0)
                    curr = curr.previous;
            mark = curr;
        }

        /**
         * Indicates wheter the current position is marked.
         * @return {@code curr == mark}
         */
        public boolean isAtMark()
        {
            return curr == mark;
        }

        /**
         * Marks the current position.
         */
        public void mark()
        {
            mark = curr;
        }

        /**
         * Indicates wheter an iteration can be performed.
         * @return 
         */
        public boolean ready()
        {
            return head != null;
        }

        @Override
        public boolean hasNext()
        {
            return ready();
        }

        @Override
        public T next()
        {
            try
            {
                index++;
                return (curr = curr.next).key;
            }
            catch (NullPointerException npe)
            {
                throw new NoSuchElementException();
            }
        }

        @Override
        public boolean hasPrevious()
        {
            return ready();
        }

        @Override
        public T previous()
        {
            try
            {
                index--;
                return (curr = curr.previous).key;
            }
            catch (NullPointerException npe)
            {
                throw new NoSuchElementException();
            }
        }

        @Override
        public int nextIndex()
        {
            return index + 1;
        }

        @Override
        public int previousIndex()
        {
            return index - 1;
        }

        @Override
        public void remove()
        {
            removeEntry(curr);
        }

        @Override
        public void set(T e)
        {
            try
            {
                curr.key = e;
            }
            catch (NullPointerException npe)
            {
                throw new NoSuchElementException();
            }
        }

        @Override
        public void add(T k)
        {
            addEntry(k, curr);
        }

    }
}