package nwsimplex.util;

import java.util.*;
import nwsimplex.graph.Edge;

/**
 * A LinkedList which is connected in a cyclic way and has most of the
 * propperties of a <tt>LinkedList<tt>: supports O(1) add and removal
 * operations. contains needs O(n).
 *
 * The main differnence however lies in the behayviour of the iterator, which is
 * a bit more faster and does not support a fast fail approach. instead the
 * iterator stays in tact, as long as there are elements in this list.
 * furthermore the current porition can be marked, since there ist no end of a
 * cyclic list.
 *
 * @author mfj
 */
public class CycleList<T> implements List<T>
{

    private int size = 0;
    private Entry head, tail;

    @Override
    public ListIterator<T> listIterator(int i)
    {
        return new CycleListIterator(i);
    }

    @Override
    public int size()
    {
        return size;
    }

    public CycleListIterator cycleListIterator()
    {
        return new CycleListIterator();
    }

    public CycleListIterator cycleListIterator(int i)
    {
        return new CycleListIterator(i);
    }

    private void addEntry(T key, Entry entry)
    {
        if (size == 0)
        {
            head = tail = new Entry(key, null, null);
            head.next = head;
            head.previous = head;
        }
        else
        {
            Entry previous = entry.previous;
            previous.next = entry.previous = new Entry(key, entry, previous);

            if (entry == tail)
                tail = tail.previous;
        }
        size++;
    }

    private void removeEntry(Entry entry)
    {
        if (size == 1)
            head = tail = null;
        else
        {
            Entry next = entry.next, previous = entry.previous;
            next.previous = previous;
            previous.next = next;
            entry.next = entry.previous = null;

            if (entry == tail)
                tail = next;

        }
        size--;
    }

    private Entry getEntry(T e)
    {
        Entry curr = head;

        if (head != null)
            if (e == null)
                do
                {
                    if (curr.key == null)
                        return curr;
                    curr = curr.next;
                }
                while (curr != head);
            else
                do
                {
                    if (e == curr.key || e.equals(curr.key))
                        return curr;
                    curr = curr.next;
                }
                while (curr != head);

        return curr;
    }

    @Override
    public boolean isEmpty()
    {
        return head == null;
    }

    @Override
    public boolean contains(Object o)
    {
        return getEntry((T) o) != null;
    }

    @Override
    public Iterator<T> iterator()
    {
        return new CycleListIterator();
    }

    @Override
    public Object[] toArray()
    {
        Object[] arr = new Object[size];
        int i = -1;
        for (T e : this)
            arr[++i] = e;
        return arr;
    }

    @Override
    public boolean add(T e)
    {
        addEntry(e, head);
        return true;
    }

    @Override
    public boolean remove(Object o)
    {
        Entry entry = getEntry((T) o);
        if (entry == null)
            return false;
        removeEntry(entry);
        return true;
    }

    @Override
    public boolean containsAll(Collection<?> clctn)
    {
        for (Object object : clctn)
            if (!contains(object))
                return false;
        return true;
    }

    @Override
    public boolean addAll(Collection<? extends T> clctn)
    {
        for (T t : clctn)
            add(t);

        return true;
    }

    @Override
    public void clear()
    {
        size = 0;
        head = tail = null;
    }

    @Override
    public <T> T[] toArray(T[] ts)
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean addAll(int i, Collection<? extends T> clctn)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public boolean removeAll(Collection<?> clctn)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public boolean retainAll(Collection<?> clctn)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public T get(int i)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public T set(int i, T e)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public void add(int i, T e)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public T remove(int i)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public int indexOf(Object o)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public int lastIndexOf(Object o)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public List<T> subList(int i, int i1)
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public ListIterator<T> listIterator()
    {
        return new CycleListIterator();
    }

    /**
     * Represents an entry for this list.
     */
    public class Entry
    {

        public T key;
        public Entry next;
        public Entry previous;

        public Entry(T key, Entry next, Entry previous)
        {
            this.key = key;
            this.next = next;
            this.previous = previous;
        }

    }

    /**
     * A faster ListIterator which does not support the failfast philosophy.
     * This iterator provides a ready method to check wheter the state of the
     * iterator is valid. Removing an element automatically advances the
     * position of the current element. Hence no check for a modcount is needed.
     */
    public class CycleListIterator implements ListIterator<T>
    {

        private Entry curr, mark;

        public CycleListIterator()
        {
            mark = curr = head;
        }

        public CycleListIterator(int i)
        {
            throw new UnsupportedOperationException("Not supported.");
        }

        /**
         * Indicates wheter the current position is marked.
         *
         * @return {@code curr == mark}
         */
        public boolean isAtMark()
        {
            return curr == mark;
        }

        /**
         * Marks the current position.
         */
        public void mark()
        {
            mark = curr;
        }

        /**
         * Indicates wheter an iteration can be performed.
         *
         * @return
         */
        public boolean ready()
        {
            return curr != null;
        }

        /**
         * Resets this iterator to the first position.
         */
        public void reset()
        {
            curr = mark = head;
        }
        
        @Override
        public boolean hasNext()
        {
            return ready();
        }

        @Override
        public T next()
        {
            try
            {
                return (curr = curr.next).key;
            }
            catch (NullPointerException npe)
            {
                throw new NoSuchElementException();
            }
        }

        @Override
        public boolean hasPrevious()
        {
            return ready();
        }

        @Override
        public T previous()
        {
            try
            {
                return (curr = curr.previous).key;
            }
            catch (NullPointerException npe)
            {
                throw new NoSuchElementException();
            }
        }

        @Override
        public int nextIndex()
        {
            throw new UnsupportedOperationException("Not supported.");
        }

        @Override
        public int previousIndex()
        {
            throw new UnsupportedOperationException("Not supported.");
        }

        @Override
        public void remove()
        {
            Entry next = curr.next;
            removeEntry(curr);
            
            if(curr == mark)
                mark = next;
            
            curr = next;
        }

        @Override
        public void set(T e)
        {
            try
            {
                curr.key = e;
            }
            catch (NullPointerException npe)
            {
                throw new NoSuchElementException();
            }
        }

        @Override
        public void add(T k)
        {
            addEntry(k, curr);
        }

    }
}
