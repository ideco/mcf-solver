package nwsimplex;

import java.io.*;
import java.text.ParseException;
import java.util.*;
import nwsimplex.IO.DIMACS;
import nwsimplex.graph.Edge;
import nwsimplex.graph.Graph;
import nwsimplex.graph.SpanningTree;
import nwsimplex.util.CycleList;
import sun.security.pkcs.ParsingException;

/**
 * A class which uses a <tt>SpanningTree<tt> instance for solving the
 * mincostflow problem by appling the network simplex algorithm.
 *
 * Note that the <tt>SpanningTree<tt> provides a consistent valid spanning tree
 * which gets updatet automatically after inserting an L or an U edge. All that
 * is left to do is providing a method which selects the entering arc.
 *
 * The entering arc selection ist done by a candidate pivot list, which selects
 * the first n best results in L and in U.
 *
 * @see SpanningTree
 * @author mfj
 */
public class NWSimplex implements Runnable
{
    // indicates wheter enough eligable arcs are left for updatiing the candidate list
    private boolean updatePivot = true;
    // number of candidates. is bound by 500, hence all candidates can be sortes in
    //prob. less then 100ms
    private int cc;
    // saves the last checked position to prevent double checking previous elements
    private CycleList<Edge>.CycleListIterator lIterator, uIterator;
    // all lowerbound edges
    private CycleList<Edge> L;
    // all upperbound edges
    private CycleList<Edge> U;
    // the candidate list
    private PriorityQueue<Edge> candidates;
    // the selforganizing spanning tree structure
    private final SpanningTree spanningTree;

    /**
     * Gets a new Instance of the <tt>NWSimplex<tt> which solves the minflow
     * problem given in form of the first feasable solution of the specified
     * spanningtree.
     *
     * @param spanningTree
     */
    public NWSimplex(SpanningTree spanningTree)
    {
        this(spanningTree, new CycleList<Edge>());
    }

    /**
     * Gets a new Instance of the <tt>NWSimplex<tt> which solves the minflow
     * problem given in form of the first feasable solution of the specified
     * spanningtree.
     *
     * @param spanningTree
     */
    public NWSimplex(SpanningTree spanningTree, CycleList<Edge> L)
    {
        this.L = L;
        
        // number of candidates ranges from 30 to 500 entries and most likely covers 5% of all edges
        int nE = spanningTree.graph.numberOfEdges;
        this.cc = Math.min((int) (0.025 * Math.max(nE, 300)), 300);
        if (cc > nE) // numof edges < 30
            cc = nE;

        this.candidates = new PriorityQueue<Edge>(cc, ReducedCostComparator.RCC);
        this.spanningTree = spanningTree;
        this.U = new CycleList<Edge>();
        this.lIterator = L.cycleListIterator();
        this.uIterator = U.cycleListIterator();
    }

    /**
     * Computes the cost of the network.
     *
     * @return
     */
    public long cost()
    {
        long cost = 0;
        Iterator<Edge> eI = spanningTree.graph.edgeIterator();
        while (eI.hasNext())
        {
            Edge e = eI.next();
            cost += e.cost * e.flow;
        }
        return cost;
    }

    /**
     * Candidate Pivot Rule for next entering Arc;
     *
     * @return
     */
    public Edge getEnteringArc()
    {
        // alwas update if candidates is empty just to be sure
        if (candidates.isEmpty() || updatePivot)
            fillCandidateList();

        // no more candidates are left
        if (candidates.isEmpty())
            return null;

        // stop updating candidates, when less then cc violating arcs left
        updatePivot = candidates.size() == cc;

        // find best feasable solution left in the candidates set
        Edge result;
        while ((result = candidates.poll()) != null)
        {
            // return result, if result is a violating arc, else put result back
            // in L or U
            if (result.hasLowerBound())
            {
                if (result.reducedCost() < 0)
                    return result;
                L.add(result);
            }
            else if (result.hasUpperBound())
            {
                if (result.reducedCost() > 0)
                    return result;
                U.add(result);
            }
        }

        // update remaining candidates
        return getEnteringArc();
    }

    // makes sure candidates.size() == cc, is as almost as fast as an
    // first eligable approach but reduzes the amount of iterations, by eliminting
    // high violating edges first
    private void fillCandidateList()
    {
        fillCandidateList(lIterator);
        fillCandidateList(uIterator);
    }

    private void fillCandidateList(CycleList<Edge>.CycleListIterator iter)
    {
        Edge e;
        
        if(!iter.ready())
            iter.reset();
        iter.mark();
        
        do
        {
            if (!iter.ready())
                break;

            if ((e = iter.next()).reducedCost() < 0)
            {
                candidates.add(e);
                iter.remove();
            }
        }
        while (candidates.size() < cc && !iter.isAtMark());
    }

    /**
     * Performs the network simplex algorithm.
     */
    @Override
    public void run()
    {
        // perform algorithm
        Edge entering, leaving;
        while ((entering = getEnteringArc()) != null)
        {
            leaving = spanningTree.addEdge(entering);
            if (leaving.hasLowerBound())
                L.add(leaving);
            else
                U.add(leaving);
        }
    }

    /**
     * Performs the network simplex algorithm an a network, which is given by a
     * DIMACS file. (Specification of the input file: http:
     * //elib.zib.de/pub/Packages/mp-testdata/mincost/netg/info) and writes the
     * result onto another file.
     *
     * @param args NWSimplex <inputfile> <outputfile>
     */
    public static void main(String[] args)
    {
        System.out.println("== ☭ для России-Матушкe ☭ ==");
        try
        {
            String fileIn, fileOut;
            if (args.length < 2)
            {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Inputfile: ");
                fileIn = scanner.nextLine();
                System.out.println("Outputfile: ");
                fileOut = scanner.nextLine();
            }
            else
            {
                fileIn = args[0];
                fileOut = args[1];
            }

            long totalTime = System.currentTimeMillis();

            BufferedReader reader = new BufferedReader(new FileReader(fileIn));

            System.out.println(" parse input file ...");
            CycleList<Edge> L = new CycleList<Edge>();
            Graph graph = DIMACS.parse(reader, L);
            reader.close();

            long computationTime = System.currentTimeMillis();
            System.out.println(" create spanning tree ...");
            SpanningTree spanningTree = new SpanningTree(graph);

            System.out.println(" run network simplex algorithm ...");
            NWSimplex simplex = new NWSimplex(spanningTree, L);
            simplex.run();

            computationTime = System.currentTimeMillis() - computationTime;

            System.out.println(" write result ... ");
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileOut));
            DIMACS.writeResult(writer, spanningTree, simplex.cost());
            writer.close();

            totalTime = System.currentTimeMillis() - totalTime;

            System.out.println("total time:      " + totalTime + " ms");
            System.out.println("computation time:" + computationTime + " ms");
        }
        catch (FileNotFoundException fnfe)
        {
            handleInvalidFile(fnfe);
        }
        catch(ParsingException pe)
        {
            handleInvalidFile(pe);
        }
        catch (Exception e)
        {
            handleUnexpectedError(e);
        }
    }

    private static void handleInvalidFile(Exception ex)
    {
        System.err.println(ex.getMessage());
        System.out.println("retry with other files? (yes/ - )");
        String retry = new Scanner(System.in).nextLine();
        if ("yes".equals(retry))
            main(new String[0]);
    }

    private static void handleUnexpectedError(Exception e)
    {
        System.err.println("an unexpected error occured!");
        System.err.println(e.getMessage());

        System.out.println("print stacktrace? (yes/ - )");
        String printStackTrace = new Scanner(System.in).nextLine();
        if ("yes".equals(printStackTrace))
            e.printStackTrace();
    }

}