/*
 #  * To change this template, choose Tools | Templates
 #  * and open the template in the editor.
 */
package nwsimplex.graph;

import java.util.*;

/**
 * A Graph structure suitable for solving an instance of the mincostflow
 * problem. This Graph is optimized for fast accsess of edges for two given
 * adjacent nodes and minimal memory usage.
 *
 * This compromise is solved by using a TreeMap for storing adjacent nodes and
 * edges given two nodes u,v the edge (u,v) can be found in log(m*) time,
 * whereby m* is the number of adjacent nodes of u: m*=card(E(u)).
 *
 * Note that the removal of nodes is not supported.
 *
 * @author mfj
 */
public class Graph
{

    public final int numberOfVertices;
    public final int numberOfEdges;
    private int lastVertexId = -1;
    private int n = 0, m = 0, maxAbsCost = 0;
    Vertex[] vertices;
    LinkedList<Edge> edges = new LinkedList<Edge>();

    /**
     *
     * @param numberOfVertices
     */
    public Graph(int numberOfVertices, int numberOfEdges)
    {
        this.numberOfVertices = numberOfVertices;
        this.numberOfEdges = numberOfEdges;
        vertices = new Vertex[numberOfVertices];
    }

    public int getM()
    {
        return m;
    }

    public int getMaxAbsCost()
    {
        return maxAbsCost;
    }

    public int getN()
    {
        return n;
    }

    /**
     * Adds a new node witch the specified balance to this graph.
     *
     * @param balance
     */
    public void addVertex(int balance, int id)
    {
        if (id >= vertices.length)
            vertices = Arrays.copyOf(vertices, id + 1);
        else if (vertices[id] != null)
            vertices[id].balance = balance;
        else
        {
            n++;
            vertices[id] = new Vertex(id, balance);
            lastVertexId = Math.max(id, lastVertexId);
        }
    }

    public Edge addEdge(int flow, int cost, int lowerCapacity, int upperCapacity, Vertex from, Vertex to)
    {
        maxAbsCost = Math.max(maxAbsCost, Math.abs(cost));
        m++;

        Edge edge = new Edge(flow, cost, lowerCapacity, upperCapacity, from, to);
        from.outgoing.add(edge);
        to.ingoing.add(edge);
        edges.add(edge);
        return edge;
    }

    public Vertex getVertex(int id)
    {
        try
        {
            return vertices[id];
        }
        catch (ArrayIndexOutOfBoundsException aioobe)
        {
            throw new NoSuchElementException();
        }
    }

    public Iterator<Vertex> vertexIterator()
    {
        return new Iterator<Vertex>()
        {

            int currPos = -1;

            @Override
            public boolean hasNext()
            {
                while (currPos < vertices.length - 1)
                {
                    if (vertices[currPos + 1] != null)
                        return true;
                    currPos++;
                }

                return false;
            }

            @Override
            public Vertex next()
            {
                if (!hasNext())
                    throw new NoSuchElementException();

                return vertices[++currPos];
            }

            @Override
            public void remove()
            {
                throw new UnsupportedOperationException("Not supported.");
            }

        };
    }

    public Iterator<Edge> edgeIterator()
    {
        return edges.iterator();
    }
}
