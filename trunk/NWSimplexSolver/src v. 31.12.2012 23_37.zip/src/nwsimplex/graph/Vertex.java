package nwsimplex.graph;

import java.util.*;

/**
 * A vertex which can be used by the network simplex algorithm.
 *
 * @author mfj
 */
public class Vertex
{

    /**
     * a unique identifier which also marks the position in the vertex[] array
     * in the corresponding Graph instance.
     */
    public final int ID;
    /**
     * balance which is defined by the min costflow instance
     */
    public int balance;
    /**
     * the potential used by the networksimplex algorithm
     */
    public int potential;
    /**
     * the depht inside the root of a spanning tree
     */
    public int depth = 1;
    /**
     * the predessor vertex within the spanning tree
     */
    public Vertex parent;
    /**
     * used to form al linked list, for child nodetraversion
     */
    public Vertex child, leftSibbling, rightSibbling;
    /**
     * the edge which points upwards to the predessesor within the spanning tree
     */
    public Edge treeEdge;
    /**
     * outgoing edges
     */
    public AdjacencyList outgoing = new AdjacencyList();
    /**
     * ingoing edges
     */
    public AdjacencyList ingoing = new AdjacencyList();

    /**
     * Instantiates a new Vertex.
     *
     * @param ID the unique identifier used by this graph.
     * @param balance the balance specified by the min-cost-flow problem
     */
    public Vertex(int ID, int balance)
    {
        this.ID = ID;
        this.balance = balance;
    }

    /**
     * Gets the sum of all capacities of ingoing edges
     */
    public int lowerInCapacity()
    {
        int cap = 0;
        for (Edge e : ingoing)
            cap += e.lowerCapacity;
        return cap;
    }

    /**
     * Gets the sum of all capacities of outgoing edges
     */
    public int lowerOutCapacity()
    {
        int cap = 0;
        for (Edge e : outgoing)
            cap += e.lowerCapacity;
        return cap;
    }

    /**
     * Gets the netto balance.
     *
     * @return b + l(d+) - l(d-) {@code balance + lowerOutCapacity() - lowerInCapacity()}
     */
    public int nettoBalance()
    {
        return balance + lowerOutCapacity() - lowerInCapacity();
    }

    /**
     * Adds this Vertex to the tree i.e. the SpanningTree
     *
     * @param parent the parent node
     */
    public void addToTree(Vertex parent, Edge e)
    {
        this.depth = parent.depth + 1;
        this.parent = parent;
        this.treeEdge = e;
        if (parent.child == null)
            parent.child = this;
        else
        {
            parent.child.leftSibbling = this;
            this.rightSibbling = parent.child;
            parent.child = this;
        }
    }

    /**
     * Removes this Vertex from the SpanningTree
     *
     * @param parent the parent node
     */
    public void removeFromTree(Vertex parent)
    {
        this.parent = null;
        this.treeEdge = null;
        if (parent.child == this)
            parent.child = null;
        else
        {
            if (rightSibbling != null)
                rightSibbling.leftSibbling = leftSibbling;
            if (leftSibbling != null)
                leftSibbling.rightSibbling = rightSibbling;
            this.rightSibbling = null;
            this.rightSibbling = null;
        }
    }

}
