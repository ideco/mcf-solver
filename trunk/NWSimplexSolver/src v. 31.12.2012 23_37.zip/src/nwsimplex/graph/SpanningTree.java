package nwsimplex.graph;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * A Spanning Tree Structure, that applies the cycle canceling rule and manages
 * the reduced cost.
 *
 * @author mfj
 */
public class SpanningTree
{

    /**
     * the graph of this spanning tree
     */
    public final Graph graph;
    /**
     * the root node of this spanning tree
     */
    public final Vertex ROOT;
    // while incrementing from the left or right side, the leaving arc can
    // either be located left or right
    private boolean leavingIsLeft;
    private Edge lEdge;
    private int minDelta;
    private LinkedList<Edge> forwardEdges = new LinkedList<Edge>();
    private LinkedList<Edge> backwardEdges = new LinkedList<Edge>();

    public SpanningTree(Graph graph)
    {
        this.graph = graph;
        this.ROOT = new Vertex(-1, 0);

        int M = 1 + (graph.getN() * graph.getMaxAbsCost()) >> 1;
        Iterator<Vertex> vertexIterator = graph.vertexIterator();
        while (vertexIterator.hasNext())
        {
            int nettoBalance;
            Edge e;
            Vertex v = vertexIterator.next();
            if ((nettoBalance = v.nettoBalance()) < 0)
            {
                e = graph.addEdge(nettoBalance, M, 0, Integer.MAX_VALUE, ROOT, v);
                v.potential = -nettoBalance;
            }
            else
            {
                e = graph.addEdge(nettoBalance, M, 0, Integer.MAX_VALUE, v, ROOT);
                v.potential = nettoBalance;
            }
            
            v.addToTree(ROOT, e);
        }
    }

    /**
     * Adds a new Edge to this <tt>SpanningTree<tt>, applies the leaving arc
     * rule and updates the tree structure.
     *
     * @param edge
     */
    public final Edge addEdge(Edge edge)
    {
        // reset state of leaving arc slgorithm
        this.minDelta = Integer.MAX_VALUE;
        forwardEdges.clear();
        backwardEdges.clear();

        // identify cycle, mindelta, leaving arc, side of leafing arc
        Vertex i, j;
        if (edge.hasUpperBound())
        {
            forwardEdges.add(edge);
            identifyCycle(i = edge.from, j = edge.to, true);
        }
        else if (edge.hasLowerBound())
        {
            backwardEdges.add(edge);
            identifyCycle(i = edge.to, j = edge.from, false);
        }
        else
            throw new IllegalArgumentException();

        // augment
        augment();

        // update spanning tree
        if (edge != lEdge)
        {
            if (leavingIsLeft)
                updateTreeLinkage(i, j, edge);
            else
                updateTreeLinkage(j, i, edge);

            updateDepthAndPotential(i, j);
        }

        return lEdge;
    }

    /**
     * Identifies a cycle within the spanningtree T, when adding a new edge
     * given by first, second), asuming of course that (first, second) is not in
     * E(T) also computes the min delta and sorts all edges into inOrder and
     * preOrder
     *
     * @param left vertex which is located left
     * @param right vertex which is located right
     * @param preferRightMin determines wheter to get the first possible min
     * within the left subcycle = {left, left.predessesor, ... , cycleRoot}
     *
     */
    // left direction means upward edges are in orinetation
    // right direction means downward pointing edges are in orientation
    private void identifyCycle(Vertex left, Vertex right, boolean preferRightMin)
    {
        while (left != right) // go up until cycle root is reached
            // second is closer to top -> move first up
            if (left.depth >= right.depth)
            {
                Edge edge = left.treeEdge;
                int delta = getEdgeDelta(edge, edge.isUpwardPointing());

                if (updateMinDelta(delta, !preferRightMin))
                {
                    this.lEdge = edge;
                    this.leavingIsLeft = true;
                }

                left = left.parent;
            }
            // first is closer to top -> move second up
            else if (left.depth <= right.depth)
            {

                Edge edge = right.treeEdge;
                int delta = getEdgeDelta(edge, edge.isDownwardPointing());

                if (updateMinDelta(delta, preferRightMin))
                {
                    this.lEdge = edge;
                    this.leavingIsLeft = false;
                }

                right = right.parent;
            }
    }

    private int getEdgeDelta(Edge e, boolean isForwardEdge)
    {
        if (isForwardEdge)
        {
            forwardEdges.add(e);
            return e.upperCapacity - e.flow;
        }
        backwardEdges.add(e);
        return e.flow - e.lowerCapacity;
    }

    private boolean updateMinDelta(int delta, boolean updateWithEquals)
    {
        if (delta < minDelta || (updateWithEquals && delta == minDelta))
        {
            this.minDelta = delta;
            return true;
        }
        return false;
    }

    /**
     * augments all edges accorind to their orientation
     */
    private void augment()
    {
        for (Edge edge : forwardEdges)
            edge.flow += minDelta;
        for (Edge edge : backwardEdges)
            edge.flow -= minDelta;
    }

    /**
     * updates predessesor relations within the cycle
     *
     * @param u the lower of both nodes
     * @param v the upper of both nodes
     * @param e the entering arc
     */
    private void updateTreeLinkage(Vertex u, Vertex v, Edge e)
    {
        Vertex minLeaving, maxLeaving;
        if (lEdge.from.depth < lEdge.to.depth)
        {
            minLeaving = lEdge.from;
            maxLeaving = lEdge.to;
        }
        else
        {
            minLeaving = lEdge.to;
            maxLeaving = lEdge.from;
        }

        u.addToTree(v, e);
        maxLeaving.removeFromTree(minLeaving);

        Vertex current = u, previous = v;
        current.treeEdge = e;
        // reverse presessesor direction to minV
        while (current != maxLeaving)
        {
            Vertex next = current.parent;
            current.parent = previous;
            previous = current;
            current = next;
        }
    }

    /**
     * updates depth and potentials within the subtree.
     *
     * @param u the lower of both nodes
     * @param v the upper of both nodes
     */
    private void updateDepthAndPotential(Vertex u, Vertex v)
    {
        updateDepthAndPotential(u, v, v.treeEdge.reducedCost());
    }

    // FIXME
    private void updateDepthAndPotential(Vertex v, Vertex parent, int change)
    {
        // update depth
        v.depth = v.parent.depth + 1;
        // updates potentials such that c* = 0
        v.treeEdge.moderatePotentials(parent, change);

        // increment
        if (v.rightSibbling != null)
            updateDepthAndPotential(v.rightSibbling, parent, change);
        else if (v.child != null)
            updateDepthAndPotential(v.child, v, change);
    }

}