package nwsimplex.graph;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * A Spanning Tree Structure, that applies the cycle canceling rule and manages
 * the reduced cost.
 *
 * @author mfj
 */
public class SpanningTree
{

    /**
     * the graph of this spanning tree
     */
    public final Graph graph;
    /**
     * the root node of this spanning tree
     */
    public final Vertex ROOT;
    // the root of the cycle
    private Vertex cycleRoot;
    // while incrementing from the left or right side, the leaving arc can
    // either be located left or right
    private boolean leavingIsLeft;
    private Edge lEdge;
    private int minDelta;
    private LinkedList<Edge> forwardEdges = new LinkedList<Edge>();
    private LinkedList<Edge> backwardEdges = new LinkedList<Edge>();

    public SpanningTree(Graph graph)
    {
//        super(graph.numberOfVertices + 1);
//        this.vertices = (Vertex[]) Arrays.copyOf(graph.vertices, numberOfVertices);
//        this.ROOT = vertices[lastNodeId = numberOfVertices - 1] = new Vertex(numberOfVertices, 0);

        this.graph = graph;
        this.ROOT = null;
        
        // TODO initialize
        // rememeber to add artificial edges
    }

    /**
     * Adds a new Edge to this <tt>SpanningTree<tt>, applies the leaving arc rule
     * and updates the tree structure.
     * @param edge
     */
    public final Edge addEdge(Edge edge)
    {
        // reset state of leaving arc slgorithm
        this.minDelta = Integer.MAX_VALUE;
        forwardEdges.clear();
        backwardEdges.clear();

        // identify cycle, mindelta, leaving arc, side of leafing arc
        Vertex left, right;
        if (edge.hasUpperBound())
        {
            forwardEdges.add(edge);
            identifyCycle(left = edge.from, right = edge.to, true);
        }
        else if (edge.hasLowerBound())
        {
            backwardEdges.add(edge);
            identifyCycle(left = edge.to, right = edge.from, false);
        }
        else
            throw new IllegalArgumentException();

        // augment
        augment();

        // update spanning tree
        if (edge != lEdge)
            if (leavingIsLeft)
                updatePredessesors(left, right, edge);
            else
                updatePredessesors(right, left, edge);

        updateThreads();
        updateNodeParameters();
        return lEdge;
    }

    /**
     * Identifies a cycle within the spanningtree T, when adding a new edge
     * given by first, second), asuming of course that (first, second) is not in
     * E(T) also computes the min delta and sorts all edges into inOrder and
     * preOrder
     *
     * @param left vertex which is located left
     * @param right vertex which is located right
     * @param preferRightMin determines wheter to get the first possible min
     * within the left subcycle = {left, left.predessesor, ... , cycleRoot}
     *
     */
    // left direction means upward edges are in orinetation
    // right direction means upward pointing edges are ageinst orientation
    private void identifyCycle(Vertex left, Vertex right, boolean preferRightMin)
    {
        while (left != right) // go up until cycle root is reached
            // second is closer to top -> move first up
            if (left.depth >= right.depth)
            {
                Edge edge = left.treeEdge;
                int delta = getEdgeDelta(edge, edge.from == left);

                if (updateMinDelta(delta, !preferRightMin))
                {
                    this.lEdge = edge;
                    this.leavingIsLeft = true;
                }

                left = left.predesessor;
            }
            // first is closer to top -> move second up
            else if (left.depth <= right.depth)
            {

                Edge edge = right.treeEdge;
                int delta = getEdgeDelta(edge, edge.to == right);

                if (updateMinDelta(delta, preferRightMin))
                {
                    this.lEdge = edge;
                    this.leavingIsLeft = false;
                }

                right = right.predesessor;
            }

        this.cycleRoot = left;
    }

    private int getEdgeDelta(Edge e, boolean isForwardEdge)
    {
        if (isForwardEdge)
        {
            forwardEdges.add(e);
            return e.upperCapacity - e.flow;
        }
        backwardEdges.add(e);
        return e.flow - e.lowerCapacity;
    }

    private boolean updateMinDelta(int delta, boolean updateWithEquals)
    {
        if (delta < minDelta || (updateWithEquals && delta == minDelta))
        {
            this.minDelta = delta;
            return true;
        }
        return false;
    }

    /**
     * augments all edges accorind to their orientation
     */
    private void augment()
    {
        for (Edge edge : forwardEdges)
            edge.flow += minDelta;
        for (Edge edge : backwardEdges)
            edge.flow -= minDelta;
    }

    /**
     * updates predessesor relations within the cycle
     *
     * @param u the lower of both nodes
     * @param v the upper of both nodes
     * @param e the entering arc
     */
    private void updatePredessesors(Vertex u, Vertex v, Edge e)
    {
        Vertex current = u, previous = v;
        current.depth = previous.depth + 1;
        Vertex maxLeaving = lEdge.from.depth < lEdge.to.depth ? lEdge.to : lEdge.from;

        current.treeEdge = e;
        // invert presessesor direction to minV
        while (current != maxLeaving)
        {
            Vertex next = current.predesessor;
            current.predesessor = previous;
            previous = current;
            current = next;

            current.depth = previous.depth + 1;
        }
    }

    private void updateThreads()
    {
        // TODO implement this fucking method its driving me nuts
    }

    private void updateNodeParameters()
    {
        // TODO updatde node potentials
    }
}


// TODO: initialisierung, ggf depths updaten, threads updaten und potentiale neu berechnen