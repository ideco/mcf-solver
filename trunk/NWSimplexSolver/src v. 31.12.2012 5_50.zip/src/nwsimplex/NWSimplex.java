package nwsimplex;

import java.io.*;
import java.util.*;
import nwsimplex.IO.DIMACS;
import nwsimplex.graph.Edge;
import nwsimplex.graph.Graph;
import nwsimplex.graph.SpanningTree;

/**
 * A class which uses a <tt>SpanningTree<tt> instance for solving the
 * mincostflow problem by appling the network simplex algorithm.
 *
 * Note that the <tt>SpanningTree<tt> provides a consistent valid spanning tree
 * which gets updatet automatically after inserting an L or an U edge. All that
 * is left to do is providing a method which selects the entering arc.
 *
 * The entering arc selection ist done by a candidate pivot list, which selects
 * the first n best results in L and in U.
 *
 * @see SpanningTree
 * @author mfj
 */
public class NWSimplex implements Runnable
{
    // indicates wheter enough eligable arcs are left for updatiing the candidate list
    private boolean updatePivot = true;
    // number of candidates. is bound by 500, hence all candidates can be sortes in
    //prob. less then 100ms
    private int cc;
    // saves the last checked position to prevent double checking previous elements
    private int lastLPosition, lastUPosition;
    // all lowerbound edges
    private List<Edge> L;
    // all upperbound edges
    private List<Edge> U;
    // the candidate list
    private PriorityQueue<Edge> candidates;
    // the selforganizing spanning tree structure
    private final SpanningTree spanningTree;

    /**
     *
     * @param spanningTree
     * @param numCandidates
     */
    public NWSimplex(SpanningTree spanningTree)
    {
        // number of candidates ranges from 30 to 500 entries and most likely covers 5% of all edges
        int nE = spanningTree.graph.numberOfEdges;
        this.cc = Math.min((int) (0.05 *  Math.max(nE, 600)), 500);
        if(cc > nE) // numof edges < 30
            cc = nE;
        
        this.candidates = new PriorityQueue<Edge>(cc, ReducedCostComparator.RCC);
        this.cc = Math.max(cc >> 1, 1);
        
        this.spanningTree = spanningTree;
        this.L = new ArrayList<Edge>(spanningTree.graph.numberOfEdges >> 1);
        this.U = new ArrayList<Edge>(spanningTree.graph.numberOfEdges >> 1);
    }

    /**
     * Computes the cost of the network.
     * @return 
     */
    public int cost()
    {
        int cost = 0;
        Iterator<Edge> eI = spanningTree.graph.edgeIterator();
        while (eI.hasNext())
        {
            Edge e = eI.next();
            cost += e.cost * e.flow;
        }
        return cost;
    }

    /**
     * Candidate Pivot Rule for next entering Arc;
     *
     * @return
     */
    public Edge getEnteringArc()
    {
        // alwas update if candidates is empty just to be sure
        if (candidates.isEmpty() || updatePivot)
            fillCandidates();
        
        // no more candidates are left
        if(candidates.isEmpty())            
            return null;
        
        // stop updating candidates, when less then cc violating arcs left
        updatePivot = candidates.size() == cc;

        // find best feasable solution left in the candidates set
        Edge result;
        while ((result = candidates.poll()) != null)
            if (isViolatingEdge(result))
                return result;

        // update remaining candidates
        return getEnteringArc();
    }

    private boolean isViolatingEdge(Edge result)
    {
        if (result.hasLowerBound() && result.reducedCost() < 0)
            return true;
        if (result.hasUpperBound() && result.reducedCost() > 0)
            return true;
        return false;
    }

    // makes sure candidates.size() == pivotCount, is as almost as fast as an
    // first eligable approach but gets a cou
    private void fillCandidates()
    {
        int l = lastLPosition, u = lastUPosition;
        Edge lEdge, uEdge;
        do
        {
            l = (l + 1) % (L.size() - 1);
            if ((lEdge= L.get(l)).reducedCost() < 0)
                candidates.add(lEdge);
        }
        while (candidates.size() < cc && l != lastLPosition);
        
        do
        {
            u = (u + 1) % (U.size() - 1);
            if ((uEdge= U.get(u)).reducedCost() > 0)
                candidates.add(uEdge);
        }
        while (candidates.size() < cc && u != lastUPosition);

        lastLPosition = l;
        lastUPosition = u;
    }
    
    /**
     * Performs the network simplex algorithm.
     */
    @Override
    public void run()
    {
        // perform algorithm
        Edge entering, leaving;
        while ((entering = getEnteringArc()) != null)
        {
            leaving = spanningTree.addEdge(entering);
            if (leaving.hasLowerBound())
                L.add(leaving);
            else
                U.add(leaving);
        }
    }

    /**
     * Performs the Network Simplex algorithm an a network, which is given by a
     * DIMACS file. (Specification of the input file: http:
     * //elib.zib.de/pub/Packages/mp-testdata/mincost/netg/info) and writes the
     * result onto another file.
     *
     * @param args NWSimplex <inputfile> <outputfile>
     */
    public static void main(String[] args)
    {
        System.out.println("== ☭ для России-Матушкe ☭ ==");
        try
        {
            String fileIn, fileOut;
            if (args.length < 2)
            {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Inputfile: ");
                fileIn = scanner.nextLine();
                System.out.println("Outputfile: ");
                fileOut = scanner.nextLine();
            }
            else
            {
                fileIn = args[0];
                fileOut = args[1];
            }

            long totalTime = System.currentTimeMillis();

            BufferedReader reader = new BufferedReader(new FileReader(fileIn));

            System.out.println(" parse input file ...");
            Graph graph = DIMACS.parse(reader);
            reader.close();

            long computationTime = System.currentTimeMillis();
            System.out.println(" create spanning tree ...");
            SpanningTree spanningTree = new SpanningTree(graph);

            System.out.println(" run network simplex algorithm ...");
            NWSimplex simplex = new NWSimplex(spanningTree);
            simplex.run();

            computationTime -= System.currentTimeMillis();

            System.out.println(" write result ... ");
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileOut));
            DIMACS.writeResult(writer, graph, simplex.cost());
            writer.close();

            totalTime -= System.currentTimeMillis();

            System.out.println("total time:      " + totalTime + " ms");
            System.out.println("computation time:" + computationTime + " ms");
        }
        catch (FileNotFoundException fnfe)
        {
            handleFileNotFound(fnfe);
        }
        catch (Exception e)
        {
            handleUnexpectedError(e);
        }
    }

    private static void handleFileNotFound(FileNotFoundException fnfe)
    {
        System.err.println(fnfe.getMessage());
        System.out.println("retry with other files? (yes/ - )");
        String retry = new Scanner(System.in).nextLine();
        if ("yes".equals(retry))
            main(new String[0]);
    }

    private static void handleUnexpectedError(Exception e)
    {
        System.err.println("an unexpected error occured!");
        System.err.println(e.getMessage());

        System.out.println("print stacktrace? (yes/ - )");
        String printStackTrace = new Scanner(System.in).nextLine();
        if ("yes".equals(printStackTrace))
            e.printStackTrace();
    }

}