/*
 #  * To change this template, choose Tools | Templates
 #  * and open the template in the editor.
 */
package nwsimplex;

/**
 * A class used to determine if the resuls produce a valid flow netowork.
 * @author mfj
 */
public class ResultChecker
{
    /**
     * 
     * @param args 
     */
    public static void main(String[] args)
    {
        
    }
}
