package nwsimplex.graph;

import java.util.*;

/**
 * A vertex which can be used by the network simplex algorithm.
 * @author mfj
 */
public class Vertex implements Comparable<Vertex>
{
    /**
     * a unique identifier which also marks the position in the vertex[] array
     * in the corresponding Graph instance.
     */
    public final int ID;
       
    /**
     * balance which is defined by the min costflow instance
     */
    public int balance;
    
    /**
     * the potential used by the networksimplex algorithm
     */
    public int potential;
    
    /**
     * the depht inside the root of a spanning tree
     */
    public int depth = 1;
    
    /**
     * the predessor vertex within the spanning tree
     */
    public Vertex predesessor;
    
    /**
     * the succsessors vertex within the spanning tree
     */
    public Vertex thread;
    
    /**
     * the edge which points upwards within the spanning tree
     */
    public Edge treeEdge;
    
    /**
     * Instantiates a new Vertext.
     * @param ID the unique identifier used by this graph.
     * @param balance the balance specified by the min-cost-flow problem
     */
    public Vertex(int ID, int balance)
    {
        this.ID = ID;
        this.balance = balance;
    }
    
    /**
     * Compares vertices by their id.
     * @param other the vertex to campare to
     * @return 
     */
    @Override
    public int compareTo(Vertex other)
    {
        return ID - other.ID;
    }

    @Override
    public boolean equals(Object o)
    {
        return o instanceof Vertex && equals((Vertex) o);
    }

    public boolean equals(Vertex v)
    {
        return this.ID == v.ID;
    }

    @Override
    public int hashCode()
    {
        return ID;
    }
}
