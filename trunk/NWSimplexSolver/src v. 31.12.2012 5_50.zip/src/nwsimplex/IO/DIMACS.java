/*
 #  * To change this template, choose Tools | Templates
 #  * and open the template in the editor.
 */
package nwsimplex.IO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.NoSuchElementException;
import nwsimplex.graph.Edge;
import nwsimplex.graph.Graph;
import sun.security.pkcs.ParsingException;

/**
 * A class that reads an writes DIMACS files.
 *
 * @author mfj
 */
public class DIMACS
{

    public static void writeResult(BufferedWriter writer, Graph graph, int cost)
    {
        // TODO add code logic
    }
    
    public static Graph parse(BufferedReader reader) throws IOException
    {

        String line = "";
        Graph graph;
        try
        {
            // find first uncommented line
            String firstLine;
            while ((firstLine = reader.readLine()) != null && !firstLine.trim().startsWith("c"));

            // parse the problem line
            String[] problemLine = firstLine.split(" ");
            if (problemLine.length != 4)
                throw new ParsingException("invalid problem line");
            int numberOfNodes = Integer.parseInt(problemLine[2]);
            int numberOfEdges = Integer.parseInt(problemLine[3]);
            graph = new Graph(numberOfNodes + 2, numberOfEdges + numberOfNodes);

            // add nodes and edges
            String[] lineArgs;
            while ((line = reader.readLine()) != null)
            {
                line = line.trim();
                lineArgs = line.split(" ");

                switch (lineArgs[0])
                {
                    case "n":
                        graph.addVertex(Integer.parseInt(lineArgs[2]), Integer.parseInt(lineArgs[1]));
                        break;
                    case "a":
                        parseEdge(lineArgs, graph);
                        break;
                    case "c":
                        break;
                    default:
                        throw new ParsingException("unknown type of line");
                }
            }

            return graph;
        }
        catch (NullPointerException npe)
        {
            throw new ParsingException("unexpected end of file");
        }
        catch (ArrayIndexOutOfBoundsException aioobe)
        {
            throw new ParsingException("invalid line " + line);
        }
        catch (NoSuchElementException nsee)
        {
            throw new ParsingException("unknown node in line " + line);
        }

    }

    private static void parseEdge(String[] lineArgs, Graph graph) throws NumberFormatException
    {
        int uID = Integer.parseInt(lineArgs[0]);
        int vID = Integer.parseInt(lineArgs[1]);
        int lowerCapacity = Integer.parseInt(lineArgs[2]);
        int upperCapacity = Integer.parseInt(lineArgs[3]);
        int cost = Integer.parseInt(lineArgs[4]);

        graph.addEdge(0, cost, lowerCapacity, upperCapacity, graph.getVertex(uID), graph.getVertex(vID));
    }

}
